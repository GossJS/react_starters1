import React from 'react';
import MyComp from './MyComp';

const data = [
  {title: "First Compo", text: "Lorem ipsum"  },
  {title: "Second Compo", text: "Quo vadis?"  },
  {title: "Latin is chique", text: "O tempora o mores"  },
  {title: "I adore Roma", text: "Status quo"  }
];

export default () => (
        <div>
          {data.map(x=>
                  <MyComp {...x}  />)}
        </div>);
